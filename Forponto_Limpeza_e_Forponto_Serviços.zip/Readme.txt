---
Utilizar ForpontoLimpeza nas m�quinas com o Forponto Executor e com Forponto sendo utilizado por usu�rios compartilhados via TS/RDS/Windows App
	
	O Objtivo � encerrar processos do Forponto.exe e FptroExec.exe presos em mem�ria, limpar arquivos tempor�rios e todo o conte�do da pasta Trab
	Deve ser executado ao menos uma vez ao dia em todas as maquinas com o Forponto


Utilizar StartService e StopService para Servi�os do Windows que necessitem de ser parados e iniciados diariamente, Ex: TComManager, TaskServ, etc.
O StartService pode ser usado v�rias vezes ao dia, para subir um Servi�o caso ele seja parado indevidamente por qualquer motivo durante o dia
	
	O objetivo � garantir que o servi�o esteja sempre no ar, mesmo que algum usu�rio o tenha parado e esquecido ou que tenha ocorrido algum erro e o servi�o n�o tenha iniciado automaticamente
	N�o verifica se o Servi�o est� travado, somente se status est� Iniciado ou Parado

---
Pode ser alterado o nome dos arquivos (Config seguir mesmo padr�o de nome), Ex: XXX.exe e XXX.exe.Config


Podem ser executados atrav�s de Tarefas Agendadas do Windows (Task Scheduler)

Pode-se utilizar o usu�rio de Sistema (System)

Executar com o maior n�vel de privil�gios




---
Ajuste as tags dos arquivos Config conforme necess�rio - seguir os exemplos e o padr�o enviados para cada um:

	Exemplo: <add key="Nome" value="Instru��o" />

	key: Nome do programa/execut�vel sem extens�o do arquivo para ForpontoLimpeza ou Nome do Servi�o (Service Name) para Start/Stop Service

	value: refere-se � instru��o a ser realizada, conforme instru��es programadas

	**Podem ser inclu�das mais linhas contendo as instru��es, uma "key" para cada "value", desde que respeite as configura��es corretamente, pois algumas possuem depend�ncia


---
Instru��es v�lidas no Config
---


Forponto Limpeza, instru��es para o campo value:

	Encerrar_Esse_Processo                          (somente para execut�veis .exe, informar o Nome do programa no campo key, sem a extens�o do arquivo)

	Apagar_Todos_Arquivos_Dessa_Pasta               (cuidado! essa instru��o apaga tudo que tiver na pasta)

	Apagar_Apenas_Arquivos_Temporarios_Dessa_Pasta  (possui depend�ncia - necessita de ao menos uma linha da instru��o abaixo, contendo extens�o de arquivos)
	Extensao_Arquivo_Temporario                     (uma linha para cada extens�o de arquivo, informado no campo key, com o sinal de ponto), Ex: .NET

	Apagar_Arquivos_Dessa_Pasta_Dias                (possui depend�ncia - necessita da linha de dias de reten��o abaixo)
	Dias_Retencao                                   (usar apenas uma linha, com o n�mero de dias no campo key), Ex: 7
---


StartService e StopService, instru��es para o campo value:

	TimeoutMilliseconds  (usar apenas uma linha com o tempo em milissegundos), Ex: 10000
	
	IniciarServico       (usar o Service Name no campo key)

	PararServico         (usar o Service Name no campo key)
---